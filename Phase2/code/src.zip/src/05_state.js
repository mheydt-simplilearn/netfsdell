class Counter extends React.Component {

  constructor(props){
    super(props);

    this.state = { count: props.count };

  }

  componentDidMount(){
    const thisIntervalHandler = this.intervalHandler.bind(this);
    setInterval(thisIntervalHandler, 1000);
  }

  intervalHandler(){
    this.setState(state => this.state.count = state.count + 1);
  }

  render() {
    return <h1>Hello, {this.state.count}</h1>;
  }
}

var element = React.createElement(Counter, { count: 100 });

document.querySelectorAll('.react_container').forEach(domContainer => {
    ReactDOM.render(element, domContainer);
});
  

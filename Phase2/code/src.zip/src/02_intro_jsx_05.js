const people = [
    {name: 'Brad'},
    {name: 'James'}
];

const Element = <ol>{people.map(person => <li key={person.name}>{person.name}</li>)}</ol>;

ReactDOM.render(
    Element,
    document.getElementById('root')
  );


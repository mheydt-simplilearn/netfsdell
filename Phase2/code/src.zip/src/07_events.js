class Counter extends React.Component {

  constructor(props){
    super(props);

    this.state = { count: props.count };

    this.handleReset = this.handleReset.bind(this);
  }

  componentDidMount(){
    const thisIntervalHandler = this.intervalHandler.bind(this);
    setInterval(thisIntervalHandler, 1000);
  }

  intervalHandler(){
    this.setState(state => this.state.count = state.count + 1);
  }

  handleReset(e){
    this.setState(state => this.state.count = 0);
  }

  render() {
    return (
      <div>
        <h1>The count is.. {this.state.count}</h1>
        <button onClick={e => this.handleReset(e)}>Reset</button>
      </div>);
  }
}

var element = React.createElement(Counter, { count: 100 });

document.querySelectorAll('.react_container').forEach(domContainer => {
    ReactDOM.render(element, domContainer);
});
  

import React from 'react'
import { render } from 'react-dom'
import { BrowserRouter } from 'react-router-dom'
import NavApp from './Components/NavApp'; 
import TransitionApp from './Components/TransitionApp'

render((
  <BrowserRouter>
    <NavApp/>
    {/*<TransitionApp />*/}
  </BrowserRouter>
), document.getElementById('root'));

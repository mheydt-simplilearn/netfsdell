const e = React.createElement;

class WhyYouNoUpdate extends React.Component {
  constructor(props) {
    super(props);

    this.state = { count: 0 };

    this.incrementCount = this.incrementCount.bind(this);
  }

  incrementCount() {
    console.log(`increment count: ${this.state.count} to ${this.state.count+1}`);
    //this.setState({count: this.state.count + 1});
    this.setState((state) => { console.log(state.count); return { count: state.count + 1 }});
  }

  handleClick(){
    this.incrementCount();
    //this.incrementCount();
    //this.incrementCount();
    //this.incrementCount();
  }

  render() {
    return e(
      'button',
      { onClick: () => this.handleClick() },
      'Update'
    );
  }
}

document.querySelectorAll('.react_container')
  .forEach(domContainer => {
    ReactDOM.render(
      e(WhyYouNoUpdate),
      domContainer
    );
  });
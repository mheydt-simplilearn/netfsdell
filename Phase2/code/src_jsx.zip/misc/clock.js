function tick() {
  console.log(new Date().toLocaleTimeString());
  var element = React.createElement(
    'div',
    null,
    React.createElement(
      'h1',
      null,
      'Hello, world!'
    ),
    React.createElement(
      'h2',
      null,
      'It is ',
      new Date().toLocaleTimeString(),
      '.'
    )
  );
  document.querySelectorAll('.react_container').forEach(function (domContainer) {
    ReactDOM.render(element, domContainer);
  });
}

setInterval(tick, 1000);
const Element = React.createElement("ol", null,
  React.createElement("li", null, "Michael"),
  React.createElement("li", null, "Heydt")
);

ReactDOM.render(
    Element,
    document.getElementById('root')
  );

ReactDOM.render(
    "HI!",
    document.getElementById('root')
  );

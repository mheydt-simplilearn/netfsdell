class Welcome extends React.Component {
  render() {
    return <h1>Hello, {this.props.name}</h1>;
  }
}

var element = React.createElement(Welcome, { name: "Mike" });
ReactDOM.render(element, document.getElementById('root'));
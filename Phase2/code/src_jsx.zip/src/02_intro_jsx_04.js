const Element = <ol>
    <li>Brad</li>
    <li>James</li>
</ol>

ReactDOM.render(
    Element,
    document.getElementById('root')
  );
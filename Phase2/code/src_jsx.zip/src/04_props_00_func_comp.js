function Welcome() {
  return <h1>Hello, ?</h1>;
}

const element = <Welcome />;

ReactDOM.render(
  element,
  document.getElementById('root')
);